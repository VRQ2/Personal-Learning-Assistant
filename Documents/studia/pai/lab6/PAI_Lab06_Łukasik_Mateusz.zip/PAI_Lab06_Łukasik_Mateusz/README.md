[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/4SqdLY94)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=23954839)
# Programowanie Aplikacji Internetowych

- Imię: Mateusz
- Nazwisko: Łukasik
- Grupa: K03

## Lab 06 - Komunikacja z API – żądania HTTP

Celem laboratorium jest poznanie sposobów komunikacji z API poprzez żądania http na przykładzie XMLHttpRequest, Fetch i Axios.

### Motyw strony

Strona obsługuje jasny i ciemny motyw. Domyślnie wykrywa ustawienia systemowe użytkownika, a po kliknięciu przycisku `Dark mode` / `Light mode` zapisuje wybrany motyw w przeglądarce. Obsługuje to plik **theme-colors.js**.

## Zadania

- Należy wykonać wszystkie zadania podane w skrypcie.
- Należy wykonać commit do lokalnego repozytorium po każdym wykonanym zadaniu (Przykładowy opis commit'u: *Task 4.1.1*)
- Należy wysłac wykonane zadania na platformę e-learning'ową oraz na GitHub Classroom
