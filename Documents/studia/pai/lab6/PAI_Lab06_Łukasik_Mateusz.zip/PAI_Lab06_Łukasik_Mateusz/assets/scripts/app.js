const postTemplate = document.getElementById('single-post');
const fetchButton = document.querySelector('#available-posts button');
const formNewPost = document.querySelector('#new-post form');
const submitButton = formNewPost.querySelector('button[type="submit"]');
const postList = document.querySelector('.posts');
const POSTS_URL = 'https://jsonplaceholder.typicode.com/posts';

// Metoda do obsługi zapytań
async function sendHttpRequest(method, url, data){
    try {
        const response = await axios({
            method: method,
            url: url,
            data: data
        });

        return response.data;
    }catch(error){
        if(error.response){
            console.log(error.response.data);
            throw new Error('Coś poszło nie tak. Kod błędu: ' + error.response.status);
        }

        throw new Error('Nieudane wysłanie żądania');
    }
}