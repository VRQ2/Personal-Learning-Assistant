const STORAGE_KEY = 'lab06-theme';
const themeToggleButton = document.querySelector('.theme-toggle');
const preferredColorScheme = window.matchMedia('(prefers-color-scheme: dark)');

const getStoredTheme = () => localStorage.getItem(STORAGE_KEY);

const getSystemTheme = () => (preferredColorScheme.matches ? 'dark' : 'light');

const applyTheme = (theme) => {
  document.documentElement.dataset.theme = theme;

  if (!themeToggleButton) {
    return;
  }

  const isDark = theme === 'dark';
  themeToggleButton.textContent = isDark ? 'Light mode' : 'Dark mode';
  themeToggleButton.setAttribute('aria-pressed', String(isDark));
};

const setTheme = (theme) => {
  localStorage.setItem(STORAGE_KEY, theme);
  applyTheme(theme);
};

applyTheme(getStoredTheme() || getSystemTheme());

themeToggleButton?.addEventListener('click', () => {
  const currentTheme = document.documentElement.dataset.theme || getSystemTheme();
  setTheme(currentTheme === 'dark' ? 'light' : 'dark');
});

preferredColorScheme.addEventListener('change', () => {
  if (!getStoredTheme()) {
    applyTheme(getSystemTheme());
  }
});
